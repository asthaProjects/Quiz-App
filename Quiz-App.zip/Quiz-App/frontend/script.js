let answers = [];

fetch("http://localhost:3000/questions")
.then(res => res.json())
.then(data => {
    const form = document.getElementById("quizForm");

    data.forEach((q, i) => {
        form.innerHTML += `
        <p>${q.question}</p>
        <input type="radio" name="q${i}" value="1"> ${q.option1}<br>
        <input type="radio" name="q${i}" value="2"> ${q.option2}<br>
        <input type="radio" name="q${i}" value="3"> ${q.option3}<br>
        <input type="radio" name="q${i}" value="4"> ${q.option4}<br><br>
        `;
    });
});

fetch("http://localhost:3000/time")
.then(res => res.json())
.then(data => {
    let time = data.time;
    setInterval(() => {
        document.getElementById("timer").innerText = "Time: " + time;
        time--;
    }, 1000);
});

function submitQuiz() {
    const inputs = document.querySelectorAll("input[type=radio]:checked");
    inputs.forEach(i => answers.push(i.value));

    fetch("http://localhost:3000/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers })
    })
    .then(res => res.json())
    .then(result => {
        alert("Score: " + result.score + "/" + result.total);
    });
}
