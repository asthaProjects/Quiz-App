Online Quiz System
Project Title

Online Quiz System (Backend-Intensive Application)

Student Name

Astha

Project Description

This project is an Online Quiz System developed using HTML, CSS, JavaScript, Node.js, Express.js, and MySQL.
It allows users to attempt a timed quiz, submit answers, and receive an automatically calculated score.
The quiz time and logic are controlled by the backend server.

Technologies Used

Frontend

HTML

CSS

JavaScript

Backend

Node.js

Express.js

Database

MySQL

Features

Server-controlled timed quiz

Secure storage of questions and answers

Automatic score calculation

Result stored in database

Relational database design

SQL queries with constraints

Admin can add questions using database

Basic error handling and validation

Project Folder Structure
Quiz-App
│
├── backend
│   ├── server.js
│   ├── db.js
│   ├── package.json
│
├── frontend
│   ├── index.html
│   ├── quiz.html
│   ├── script.js
│   └── style.css
│
└── database
    └── quiz.sql

How to Run the Project
Step 1: Database Setup

Open MySQL Command Line

Run the SQL code from quiz.sql

Step 2: Backend Setup

Open Command Prompt in the backend folder and run:

npm install
node server.js

Step 3: Frontend

Open frontend/index.html in a browser

Click Start Quiz

Answer questions and submit

Quiz Timer

The quiz timer is controlled from the backend and can be changed in server.js:

let quizTime = 120 seconds;

Conclusion

This project demonstrates a complete full-stack web application with frontend, backend, and database integration. It provides a simple and efficient way to conduct online quizzes with automated evaluation.

Thank You