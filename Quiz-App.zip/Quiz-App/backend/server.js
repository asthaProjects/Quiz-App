const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let quizTime = 120; // 60 seconds

// Get questions
app.get('/questions', (req, res) => {
    db.query("SELECT * FROM questions", (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});

// Submit quiz
app.post('/submit', (req, res) => {
    const answers = req.body.answers;
    let score = 0;

    db.query("SELECT * FROM questions", (err, questions) => {
        questions.forEach((q, i) => {
            if (answers[i] == q.correct_option) {
                score++;
            }
        });

        db.query(
            "INSERT INTO results (score, total) VALUES (?,?)",
            [score, questions.length]
        );

        res.json({ score, total: questions.length });
    });
});

// Timer
app.get('/time', (req, res) => {
    res.json({ time: quizTime });
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});
